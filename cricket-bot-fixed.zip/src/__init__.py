"""Cricket simulator bot package."""
